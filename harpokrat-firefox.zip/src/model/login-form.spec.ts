import { LoginForm } from './login-form';

describe('LoginForm', () => {
  it('should create an instance', () => {
    expect(new LoginForm('a', 'b')).toBeTruthy();
  });
});
