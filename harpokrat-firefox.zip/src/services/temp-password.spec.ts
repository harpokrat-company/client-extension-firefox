import { TempPassword } from './temp-password';

describe('TempPassword', () => {
  it('should create an instance', () => {
    expect(new TempPassword()).toBeTruthy();
  });
});
