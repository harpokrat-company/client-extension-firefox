/* TODO : replace with nglib model */
/**
 * @deprecated
 */
export class TempPassword {
  id: number;
  name: string;
  secret: string;
  domain: string;
  icon: string;
}
