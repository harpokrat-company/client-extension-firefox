export const environment = {
  production: true,
  apiUrl: 'https://api.harpokrat.com/v1'
};
